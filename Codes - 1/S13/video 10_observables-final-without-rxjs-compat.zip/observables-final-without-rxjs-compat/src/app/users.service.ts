import { Subject } from 'rxjs';

export class UsersService {
  userActivated = new Subject();
}
